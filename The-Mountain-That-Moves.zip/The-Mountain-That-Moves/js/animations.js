/* ==========================================================================
   THE MOUNTAIN THAT MOVES — animations.js
   One requestAnimationFrame loop draws ALL particles (snow, embers, wisps,
   bursts...) so nothing fights over the canvas. game.js talks to this file
   through the global `MountainFX` object at the bottom.
   ========================================================================== */
(function () {
  "use strict";

  const motionQuery = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
  const reduced = () => motionQuery.matches;

  // How many of each particle type to keep alive in each scene (at 800px wide).
  const SCENES = {
    camp:   { snow: 30, ember: 6 },
    gate:   { snow: 26, ember: 7 },
    ravine: { snow: 12, wisp: 16 },
    echoes: { snow: 10, mote: 18, streak: 2 },
    ridge:  { ash: 30, snow: 8 },
    summit: { mote: 26, snow: 8 },
    dawn:   { firefly: 18, snow: 6 }
  };

  let canvas = null, ctx = null, W = 800, H = 300, dpr = 1;
  let scene = "camp";
  let ambient = [];            // long-lived scene particles
  let bursts = [];             // short-lived choice bursts / sparkles
  let rafId = 0, lastT = 0;
  let viewport = null;
  let px = 0, py = 0, tx = 0, ty = 0;   // pointer parallax (current / target)

  const rnd = (a, b) => a + Math.random() * (b - a);
  const density = () => Math.max(0.5, Math.min(1, W / 800));

  /* ---------- particle factories ---------- */
  function make(type, initial) {
    const x = rnd(0, W), y = initial ? rnd(0, H) : -6;
    switch (type) {
      case "snow":   return { type, x, y, r: rnd(.6, 1.9), vx: rnd(-.15, .3), vy: rnd(.25, .7), a: rnd(.25, .7), c: "#e6e4e0", ph: rnd(0, 6.3) };
      case "ember":  return { type, x: rnd(.28, .5) * W, y: initial ? rnd(.5, .95) * H : H * .92, r: rnd(.7, 1.6), vx: rnd(-.12, .12), vy: -rnd(.15, .45), a: rnd(.4, .9), c: "#ffcf70", ph: rnd(0, 6.3), life: rnd(.4, 1) };
      case "wisp":   return { type, x, y: initial ? rnd(0, H) : H + 6, r: rnd(1.2, 2.6), vx: 0, vy: -rnd(.18, .5), a: rnd(.15, .5), c: "#cfe6ff", ph: rnd(0, 6.3), amp: rnd(.2, .6) };
      case "mote":   return { type, x, y: initial ? rnd(0, H) : H + 6, r: rnd(.7, 1.8), vx: rnd(-.1, .1), vy: -rnd(.05, .22), a: rnd(.2, .7), c: scene === "summit" ? "#ffe29a" : "#c9d6ea", ph: rnd(0, 6.3) };
      case "ash":    return { type, x, y, r: rnd(.7, 1.9), vx: rnd(.3, .9), vy: rnd(.2, .6), a: rnd(.25, .6), c: Math.random() < .35 ? "#e5703a" : "#9a8f86", ph: rnd(0, 6.3) };
      case "firefly":return { type, x, y: initial ? rnd(.3, 1) * H : rnd(.5, 1) * H, r: rnd(1, 2), vx: rnd(-.25, .25), vy: rnd(-.2, .2), a: 0, c: "#ffd98a", ph: rnd(0, 6.3) };
      case "streak": return { type, x: -40, y: rnd(.1, .6) * H, len: rnd(40, 90), vx: rnd(3, 5), vy: rnd(.1, .4), a: rnd(.08, .16), c: "#dce9ff", wait: rnd(0, 400) };
    }
  }

  function populate() {
    ambient = [];
    const cfg = SCENES[scene] || SCENES.camp;
    const d = density();
    for (const type in cfg) {
      const n = Math.round(cfg[type] * d);
      for (let i = 0; i < n; i++) ambient.push(make(type, true));
    }
  }

  /* ---------- update + draw ---------- */
  function step(p, dt, t) {
    p.x += p.vx * dt; p.y += p.vy * dt;
    switch (p.type) {
      case "snow":  p.x += Math.sin(t / 1400 + p.ph) * .25 * dt; if (p.y > H + 4) Object.assign(p, make("snow", false)); break;
      case "ember": p.x += Math.sin(t / 700 + p.ph) * .2 * dt; p.life -= .004 * dt; p.a = Math.max(0, p.life) * .9; if (p.life <= 0) Object.assign(p, make("ember", false), { life: rnd(.6, 1) }); break;
      case "wisp":  p.x += Math.sin(t / 1200 + p.ph) * p.amp * dt; if (p.y < -6) Object.assign(p, make("wisp", false)); break;
      case "mote":  p.x += Math.sin(t / 1800 + p.ph) * .15 * dt; p.a = .35 + .35 * Math.sin(t / 900 + p.ph); if (p.y < -6) Object.assign(p, make("mote", false)); break;
      case "ash":   if (p.y > H + 4 || p.x > W + 6) Object.assign(p, make("ash", false), { x: rnd(-40, W) }); break;
      case "firefly": p.vx += rnd(-.02, .02) * dt; p.vy += rnd(-.02, .02) * dt; p.vx = Math.max(-.3, Math.min(.3, p.vx)); p.vy = Math.max(-.25, Math.min(.25, p.vy));
                      p.a = Math.max(0, .15 + .75 * Math.sin(t / 700 + p.ph)); if (p.x < 0) p.x = W; if (p.x > W) p.x = 0; if (p.y < 0) p.y = H; if (p.y > H) p.y = 0; break;
      case "streak": if (p.wait > 0) { p.wait -= dt; p.x = -999; } else { if (p.x < -500) p.x = -40; if (p.x > W + 100) Object.assign(p, make("streak"), { wait: rnd(200, 700) }); } break;
    }
  }

  function draw(p) {
    if (p.a <= 0.01) return;
    ctx.globalAlpha = Math.min(1, p.a);
    ctx.fillStyle = p.c;
    if (p.type === "streak") { ctx.fillRect(p.x, p.y, p.len, 1); return; }
    ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832); ctx.fill();
    if (p.type === "ember" || p.type === "firefly" || p.burst) {   // cheap glow: a second, larger, fainter dot
      ctx.globalAlpha = Math.min(1, p.a) * .22;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 3.2, 0, 6.2832); ctx.fill();
    }
  }

  function frame(t) {
    rafId = requestAnimationFrame(frame);
    const dt = Math.min(2.5, (t - (lastT || t)) / 16.67); lastT = t;
    ctx.clearRect(0, 0, W, H);
    for (const p of ambient) { step(p, dt, t); draw(p); }
    for (let i = bursts.length - 1; i >= 0; i--) {
      const p = bursts[i];
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += .018 * dt; p.vx *= .995; p.a -= .013 * dt;
      if (p.a <= 0) { bursts.splice(i, 1); continue; }
      draw(p);
    }
    ctx.globalAlpha = 1;
    // smooth pointer parallax
    px += (tx - px) * .06; py += (ty - py) * .06;
    if (viewport) { viewport.style.setProperty("--px", px.toFixed(3)); viewport.style.setProperty("--py", py.toFixed(3)); }
  }

  /* ---------- setup ---------- */
  function resize() {
    if (!canvas) return;
    const r = canvas.parentElement.getBoundingClientRect();
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = r.width || 800; H = r.height || 300;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    populate();
  }

  function applyMotionPreference() {
    cancelAnimationFrame(rafId); rafId = 0;
    if (ctx) ctx.clearRect(0, 0, W, H);
    if (viewport) { viewport.style.setProperty("--px", 0); viewport.style.setProperty("--py", 0); }
    if (!reduced() && ctx) { lastT = 0; rafId = requestAnimationFrame(frame); }
  }

  function init() {
    canvas = document.getElementById("scene-canvas");
    viewport = document.getElementById("mountain-viewport");
    if (!canvas || !canvas.getContext) return;
    ctx = canvas.getContext("2d");
    resize();
    window.addEventListener("resize", resize);
    if (viewport) {
      viewport.addEventListener("pointermove", (e) => {
        if (e.pointerType === "touch" || reduced()) return;
        const r = viewport.getBoundingClientRect();
        tx = ((e.clientX - r.left) / r.width - .5) * 2; ty = ((e.clientY - r.top) / r.height - .5) * 2;
      });
      viewport.addEventListener("pointerleave", () => { tx = 0; ty = 0; });
    }
    if (motionQuery.addEventListener) motionQuery.addEventListener("change", applyMotionPreference);
    applyMotionPreference();
  }

  /* ---------- public API used by game.js ---------- */
  function restart(el, cls, ms) {
    if (!el) return;
    el.classList.remove(cls); void el.getBoundingClientRect(); el.classList.add(cls);
    setTimeout(() => el.classList.remove(cls), ms);
  }

  window.MountainFX = {
    /** Switch the ambient particle mix: camp, gate, ravine, echoes, ridge, summit, dawn */
    setScene(name) {
      if (!SCENES[name] || name === scene) return;
      scene = name; document.body.dataset.scene = name; populate();
    },
    /** One-off burst of sparks. kind: "sacrifice" | "bargain" | "descent" (or pass a colour) */
    burst(color = "#d4af37", count = 30, x, y) {
      if (reduced() || !canvas) return;
      const cx = x ?? W * .52, cy = y ?? H * .72;
      for (let i = 0; i < count && bursts.length < 160; i++) {
        const a = Math.random() * 6.2832, s = rnd(.5, 2.6);
        bursts.push({ type: "burst", burst: true, x: cx, y: cy, r: rnd(.8, 2.2), vx: Math.cos(a) * s, vy: Math.sin(a) * s - .6, a: .95, c: color });
      }
    },
    sparkle(x, y, color = "#d4af37") { this.burst(color, 12, x, y); },
    /** Coloured light pulse + traveler reaction. kind: "sacrifice" | "bargain" | "descent" */
    react(kind) {
      if (reduced()) return;
      restart(document.getElementById("choice-flash"), "flash-" + kind, 1000);
      restart(document.getElementById("svg-lantern"), "surge", 900);
      restart(document.getElementById("traveler-cloak"), "flare", 800);
      if (kind === "sacrifice") restart(document.getElementById("mountain-viewport"), "shake", 450);
    },
    isReduced: reduced
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
