/* ==========================================================================
   THE MOUNTAIN THAT MOVES — game.js
   Story data, game state, save/load, screens and modals.
   Visual effects are in animations.js (MountainFX).
   ========================================================================== */
    /********************************************************************
     * THE MOUNTAIN THAT MOVES — Interactive Visual Slide & Branching Engine
     ********************************************************************/

    const STORAGE_KEY = "mountain_that_moves_save_v3";

    // --- Small helpers -----------------------------------------------------
    // Escape text typed by the player before it goes into innerHTML (prevents broken layouts / HTML injection).
    const esc = (str) => String(str ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    // First letter of the player's birth name (used for the "carved initial").
    const initialOf = (p, raw = false) => {
      const i = ((p.originalName || "A").trim()[0] || "A").toUpperCase();
      return raw ? i : esc(i);
    };
    // Visual effects live in js/animations.js. If it failed to load the game still works.
    const FX = window.MountainFX || { setScene() {}, burst() {}, react() {}, sparkle() {}, isReduced: () => false };
    let busy = false;   // blocks double-clicks while a choice is animating

    const defaultPlayerState = () => ({
      screen: "title", // 'title' | 'setup' | 'journey' | 'sacrifice' | 'consequence' | 'summit' | 'ending'
      checkpoint: 0,   // 0: Base Camp, 1: Obsidian Gate, 2: Weeping Ravine, 3: Hall of Echoes, 4: Sunless Ridge, 5: Moving Summit
      originalName: "",
      name: "",
      wishKey: "",
      wishText: "",
      vitality: 100,
      keptMemoryText: "A weathered silver pocket-watch and a folded letter from someone waiting by the valley hearth.",
      sacrifices: {
        lantern: false,
        frostbitten: false,
        belongings: false,
        burnedSupplies: false,
        name: false,
        carvedPalm: false,
        shadow: false,
        ironShadow: false
      },
      lastChoiceType: "",
      finalDecision: "",
      turnBackAttempts: 0
    });

    let player = defaultPlayerState();

    const WISH_OPTIONS = [
      {
        key: "power",
        label: "To become powerful beyond reach",
        wishText: "to possess strength so absolute that nothing can ever harm or command me again"
      },
      {
        key: "remembered",
        label: "To be remembered forever",
        wishText: "to carve my name into eternity so I am never forgotten when I am gone"
      },
      {
        key: "undo",
        label: "To undo a past mistake",
        wishText: "to return to the hour everything broke and remake the choice I cannot forgive"
      },
      {
        key: "obtain",
        label: "To obtain what was always denied to me",
        wishText: "to finally hold the life and peace that remained just out of reach"
      },
      {
        key: "custom",
        label: "To speak a private wish of my own...",
        wishText: ""
      }
    ];

    const CHECKPOINTS = {
      1: {
        slideBadge: "SLIDE 01 // THE OBSIDIAN GATE",
        title: "Checkpoint I — The Obsidian Gate",
        location: "The Obsidian Gate",
        apparentDistance: "1,450m",
        summitScale: 0.86,
        story: (p) => `
          The timberline falls away behind ${getDisplayName(p, true)}. Above, an ancient arch of volcanic glass—the Obsidian Gate—stands carved into the cliffside.
          <br><br>
          In ${getPossessive(p)} hand, the camp lantern hums with golden warmth, illuminating a roadside rune tablet. Beyond the arch, ink-black thorn-darkness coils across the narrow ledge.
          <br><br>
          A low vibration hums from the stone: <em>“No borrowed fire passes the gate uncollected.”</em> Yet below the ridge, the warm amber lights of the valley village are still visible through the mist.
        `,
        inscription: "“Count the steps before the light is given. The peak recedes from eyes that demand to see.”",
        choices: [
          {
            id: "lantern",
            type: "sacrifice",
            tag: "Option A — The Full Sacrifice",
            title: "Surrender Your Lantern to the Obsidian Altar",
            desc: "Extinguish your light for clean, unharmed passage. The world will dim into shadow and roadside tablets will become unreadable.",
            toast: "Slide 01: The lantern flame dies into golden smoke..."
          },
          {
            id: "briars",
            type: "alternate",
            tag: "Option B — Defiant Bargain (-25 Vitality)",
            title: "Shield the Lantern & Force Through the Thorn-Darkness",
            desc: "Keep a flickering half-light to read the stones ahead, but suffer Frostbite Scars as the freezing thorns tear your cloak and hands.",
            toast: "Slide 01: You shield a flickering half-light; frostbite scars your hands..."
          },
          {
            id: "descent_1",
            type: "descent",
            tag: "Option C — Give Up & Turn Back",
            title: "Turn Back While the Valley Lights Still Glow Below",
            desc: "Refuse the mountain's first demand. Walk back down to the village intact and warm, leaving your wish unanswered.",
            toast: "Slide 06: Turning back toward the warm lights of the valley..."
          }
        ],
        consequenceText: (p) => {
          if (p.sacrifices.lantern) {
            return `
              ${getDisplayName(p, false)} sets the brass lantern upon the obsidian plinth. Its golden flame stretches upward once—and vanishes.
              <br><br>
              Ink-black shadow floods the cliffside. You pass through the gate unscathed, but the mountain ahead must now be climbed by touch alone.
            `;
          }
          return `
            Curving ${getPossessive(p)} body around the glass chimney of the lantern, ${getDisplayName(p, true)} forces a path through the freezing thorn-darkness.
            <br><br>
            A sputtering half-light survives inside the cracked glass, still strong enough to read the trail—but deep frostbite scars your trembling fingers.
          `;
        }
      },
      2: {
        slideBadge: "SLIDE 02 // THE WEEPING RAVINE",
        title: "Checkpoint II — The Weeping Ravine",
        location: "The Weeping Ravine",
        apparentDistance: "1,850m",
        summitScale: 0.72,
        story: (p) => `
          ${p.sacrifices.lantern
            ? "Without the lantern, only the sound of wind echoing up from an unseen abyss warns where the cliff ends."
            : "Your cracked lantern casts a shivering glow across a vast chasm where pale mist rises like weeping breath."}
          <br><br>
          Inside ${getPossessive(p)} coat rests a silver pocket-watch and a folded letter from home—the very reason the wish to <em>“${esc(p.wishText)}”</em> burns in your chest.
          <br><br>
          A frayed rope bridge spans the ravine. Floating wisps of other climbers' forgotten photographs drift upward from the chasm: the bridge snaps under anyone who carries the weight of their past.
        `,
        inscription: "“What anchors you to the valley anchors your feet to the abyss. Surrender what you love, or burn what keeps you warm.”",
        choices: [
          {
            id: "belongings",
            type: "sacrifice",
            tag: "Option A — The Full Sacrifice",
            title: "Surrender Your Belongings & Memories to the Ravine",
            desc: "Drop the watch and letter into the mist. You cross effortlessly, but every memory of home and why you wished this will vanish.",
            toast: "Slide 02: Your keepsakes dissolve into rising memory wisps..."
          },
          {
            id: "burn_supplies",
            type: "alternate",
            tag: "Option B — Defiant Bargain (-25 Vitality)",
            title: "Cling to One Precious Memory & Burn Your Supplies Instead",
            desc: "Fiercely keep the folded letter so you remember who you love, but cast your rations and heavy wool pack into the ravine.",
            toast: "Slide 02: You save one precious memory, sacrificing your warmth..."
          },
          {
            id: "descent_2",
            type: "descent",
            tag: "Option C — Give Up & Turn Back",
            title: "Turn Back From the Ravine Bridge Toward Home",
            desc: "Refuse to erase your past or starve on the upper ridges. Descend the mountain now with the memories you still hold.",
            toast: "Slide 06: Retracing your steps down from the Weeping Ravine..."
          }
        ],
        consequenceText: (p) => {
          if (p.sacrifices.belongings) {
            return `
              The silver watch and folded letter fall into the pale mist of the Weeping Ravine, rising back up as weightless, glowing wisps.
              <br><br>
              By the far side of the bridge, ${getDisplayName(p, true)} can no longer picture the face of the person who wrote the letter, nor the room they left behind.
            `;
          }
          return `
            Pressing the folded letter inside ${getPossessive(p)} shirt, ${getDisplayName(p, true)} unstraps the heavy supply pack and hurls it into the ravine instead.
            <br><br>
            The memory of home survives intact—you still know why you climb—though the high altitude wind cuts straight through your thin, supply-less coat.
          `;
        }
      },
      3: {
        slideBadge: "SLIDE 03 // THE HALL OF ECHOES",
        title: "Checkpoint III — The Hall of Echoes",
        location: "The Hall of Echoes",
        apparentDistance: "2,420m",
        summitScale: 0.56,
        story: (p) => `
          Towering monolith mirrors of polished slate line the ridge, reflecting ${getDisplayName(p, true)} in silver distortion. Faceless stone statues kneel between the pillars.
          <br><br>
          A weathered climber huddled against the base of a mirror whispers, <em>“The Hall of Echoes hears the name <strong>${esc(p.originalName)}</strong> beating behind your ribs.”</em>
          <br><br>
          Swirling silver runes bar the archway ahead. Here the mountain asks for the name by which the world knows you.
        `,
        inscription: "“A name is a debt owed to those who spoke it first. Leave it in the mirror, or carve its scar into your flesh.”",
        choices: [
          {
            id: "name",
            type: "sacrifice",
            tag: "Option A — The Full Sacrifice",
            title: "Surrender Your Name to the Monolith Mirror",
            desc: "Let the mirror drink your identity. You pass unburdened, but become 'The Stranger' forever—even in your own thoughts.",
            toast: "Slide 03: Your reflection keeps your name; The Stranger walks on..."
          },
          {
            id: "carve_palm",
            type: "alternate",
            tag: "Option B — Defiant Bargain (-25 Vitality)",
            title: "Carve Your First Initial into Your Palm So You Won't Forget",
            desc: (p) => `Surrender the full sound of your name to the wind, but keep your initial ('${initialOf(p)}.') carved in your palm as voices fracture around you.`,
            toast: "Slide 03: You carve your initial into your palm against the echoes..."
          },
          {
            id: "descent_3",
            type: "descent",
            tag: "Option C — Give Up & Turn Back",
            title: "Refuse the Mirrors & Walk Back Down With Your Name",
            desc: "Abandon the summit before the Hall of Echoes strips away who you are. Return to the valley carrying what remains.",
            toast: "Slide 06: Turning away from the mirrors to descend the mountain..."
          }
        ],
        consequenceText: (p) => {
          if (p.sacrifices.name) {
            return `
              Your reflection inside the monolith mouths the name <em>${esc(p.originalName)}</em> one last time—and keeps it.
              <br><br>
              The old climber beside the pillar blinks in confusion. <em>“Who goes there? Only a nameless stranger walks this ridge.”</em>
            `;
          }
          const initial = initialOf(p);
          return `
            With a sharp shard of slate, you press the letter <strong>${initial}.</strong> into your frost-numbed palm before the mirror can steal it all.
            <br><br>
            The statues whisper in fractured, overlapping echoes. You can no longer hear your full name clearly, yet whenever you look down at your hand, the letter <strong>${initial}.</strong> anchors your mind.
          `;
        }
      },
      4: {
        slideBadge: "SLIDE 04 // THE SUNLESS RIDGE",
        title: "Checkpoint IV — The Sunless Ridge",
        location: "The Sunless Ridge",
        apparentDistance: "3,150m",
        summitScale: 0.42,
        story: (p) => `
          Beneath a blood-gold eclipse, the mountain narrows to a razor-thin spine of blue glacier.
          <br><br>
          Stretched long across the rock behind ${getDisplayName(p, true)} lies ${getPossessive(p)} shadow—trembling, straining to detach itself and slide back down toward the valley.
          <br><br>
          The final spire rises just beyond the eclipse. To step onto the Moving Summit, the ridge demands the shadow that tethers your heels to the world below.
        `,
        inscription: "“A shadow always points back down the mountain. Sever it to rise weightless—or pin it with iron and drag the earth with you.”",
        choices: [
          {
            id: "shadow",
            type: "sacrifice",
            tag: "Option A — The Full Sacrifice (Irreversible)",
            title: "Sever Your Shadow & Leave It on the Sunless Ridge",
            desc: "Step weightlessly onto the summit. Your shadow vanishes from the slide, and you can NEVER turn back or descend again.",
            toast: "Slide 04: Your shadow detaches and vanishes into the eclipse..."
          },
          {
            id: "iron_shadow",
            type: "alternate",
            tag: "Option B — Defiant Bargain (-20 Vitality)",
            title: "Pin Your Shadow to Your Heels with Iron Pitons",
            desc: "Keep a tattered shadow and preserve the ability to turn back at the summit, though every step weighs twice as much.",
            toast: "Slide 04: You pin your tattered shadow with iron; gravity doubles..."
          },
          {
            id: "descent_4",
            type: "descent",
            tag: "Option C — Final Chance to Turn Back",
            title: "Gaze at the Eclipse, Then Follow Your Shadow Back Down",
            desc: "Stand at the threshold of the summit, refuse the final severance, and walk back down into the valley while you still cast a shadow.",
            toast: "Slide 06: Following your shadow down from the Sunless Ridge..."
          }
        ],
        consequenceText: (p) => {
          if (p.sacrifices.shadow) {
            return `
              Under the blood-gold eclipse, your shadow peels free from your heels and slips silently down the glacier without you.
              <br><br>
              ${getDisplayName(p, false)} casts no mark upon the snow now. Behind you, the downward trail dissolves into a wall of void. Only the summit remains.
            `;
          }
          return `
            Driving an iron spike through the hem of your shadow, ${getDisplayName(p, true)} binds the dark silhouette to ${getPossessive(p)} heels.
            <br><br>
            The glacier shudders under double gravity. Every breath burns like molten lead—yet your tattered shadow still trails behind you, keeping the road home alive.
          `;
        }
      }
    };

    /********************************************************************
     * WEB AUDIO SYNTHESIZER & AMBIENT SOUND ENGINE
     ********************************************************************/
    let soundEnabled = false;
    let audioCtx = null;

    function toggleSound() {
      soundEnabled = !soundEnabled;
      const btn = document.getElementById("btn-sound");
      if (btn) {
        btn.textContent = soundEnabled ? "Sound: On" : "Sound: Off";
        btn.setAttribute("aria-pressed", String(soundEnabled));
        btn.classList.toggle("text-[#d4af37]", soundEnabled);
      }
      if (soundEnabled) {
        if (!audioCtx) {
          const AudioContextClass = window.AudioContext || window.webkitAudioContext;
          if (AudioContextClass) audioCtx = new AudioContextClass();
        }
        playSacrificeTone(220);
      }
    }

    function playSacrificeTone(freq = 160) {
      if (!soundEnabled || !audioCtx) return;
      try {
        if (audioCtx.state === "suspended") audioCtx.resume();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(Math.max(45, freq * 0.65), audioCtx.currentTime + 1.1);

        gain.gain.setValueAtTime(0.001, audioCtx.currentTime);
        gain.gain.linearRampToValueAtTime(0.08, audioCtx.currentTime + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 1.15);

        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 1.2);
      } catch (e) {
        // Ignore audio errors if blocked by browser autoplay policy
      }
    }

    let toastTimer = null;
    function showSlideActionToast(text) {
      const toast = document.getElementById("slide-action-toast");
      const span = document.getElementById("slide-action-text");
      if (!toast || !span || !text) return;
      span.textContent = text;
      toast.classList.remove("opacity-0");
      toast.classList.add("opacity-100");
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => {
        toast.classList.remove("opacity-100");
        toast.classList.add("opacity-0");
      }, 2600);
    }

    /********************************************************************
     * SAVE & LOAD STATE (localStorage)
     ********************************************************************/
    function saveState() {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(player));
      } catch (e) {
        // Ignore storage errors in restricted environments
      }
    }

    function loadState() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return;
        const parsed = JSON.parse(raw);
        const next = Object.assign(defaultPlayerState(), parsed);
        next.sacrifices = Object.assign(defaultPlayerState().sacrifices, parsed.sacrifices || {});
        const screens = ["title", "setup", "journey", "consequence", "summit", "ending"];
        const needsCheckpoint = next.screen === "journey" || next.screen === "consequence";
        if (!screens.includes(next.screen) || !(next.checkpoint >= 0 && next.checkpoint <= 5) ||
            (needsCheckpoint && !CHECKPOINTS[next.checkpoint]) || (next.screen === "ending" && !next.finalDecision)) {
          throw new Error("Unusable save");
        }
        player = next;
      } catch (e) {
        player = defaultPlayerState();   // corrupt or blocked storage: start fresh
      }
    }

    function goBackToTitle() {
      player.screen = "title";
      saveState();
      triggerSlideShutter();
      renderCurrentScreen();
    }

    function startNewClimb() {
      busy = false;
      player = defaultPlayerState();
      saveState();
      triggerSlideShutter();
      renderCurrentScreen();
    }

    /********************************************************************
     * HELPER FUNCTIONS FOR REACTIVE NARRATIVE & STATE
     ********************************************************************/
    function getDisplayName(p, lowercaseInSentence = false) {
      if (p.sacrifices.name) {
        return lowercaseInSentence ? "the stranger" : "The Stranger";
      }
      if (p.sacrifices.carvedPalm) {
        const init = initialOf(p);
        return `${init}.`;
      }
      return esc(p.name || "the traveler");
    }

    function getPossessive(p) {
      if (p.sacrifices.name) {
        return "the stranger's";
      }
      return "their";
    }

    function triggerSlideShutter() {
      const shutter = document.getElementById("slide-shutter");
      if (!shutter) return;
      shutter.classList.remove("opacity-0");
      shutter.classList.add("opacity-90");
      setTimeout(() => {
        shutter.classList.remove("opacity-90");
        shutter.classList.add("opacity-0");
      }, 220);
    }

    function toggleSlideInspect(forceState) {
      const overlay = document.getElementById("slide-inspect-overlay");
      if (!overlay) return;
      const shouldShow = typeof forceState === "boolean" ? forceState : overlay.classList.contains("hidden");
      if (shouldShow) {
        updateSlideInspectOverlay();
        overlay.classList.remove("hidden");
      } else {
        overlay.classList.add("hidden");
      }
    }

    function updateSlideInspectOverlay() {
      const box = document.getElementById("slide-inspect-content");
      const wishSpan = document.getElementById("slide-inspect-wish");
      if (!box) return;

      const lightState = player.sacrifices.lantern
        ? `<span class="text-[#7a828e]">Extinguished (Inscriptions Blurred)</span>`
        : (player.sacrifices.frostbitten
          ? `<span class="text-[#6ab0de]">Flickering Half-Light (Frostbite Scars)</span>`
          : `<span class="text-[#d4af37]">Golden Camp Lantern (Intact)</span>`);

      const memoryState = player.sacrifices.belongings
        ? `<span class="text-[#7a828e]">Surrendered to Ravine (Reason Forgotten)</span>`
        : (player.sacrifices.burnedSupplies
          ? `<span class="text-[#6ab0de]">One Memory Saved (Supplies Burned)</span>`
          : `<span class="text-[#e6e4e0]">Watch & Letter Intact</span>`);

      const nameState = player.sacrifices.name
        ? `<span class="text-[#7a828e]">Erased (“The Stranger”)</span>`
        : (player.sacrifices.carvedPalm
          ? `<span class="text-[#6ab0de]">Initial “${initialOf(player)}.” Carved in Palm</span>`
          : `<span class="text-[#e6e4e0]">${esc(player.originalName || "Unspoken")}</span>`);

      const shadowState = player.sacrifices.shadow
        ? `<span class="text-[#b83b2b]">Severed (Cannot Turn Back)</span>`
        : (player.sacrifices.ironShadow
          ? `<span class="text-[#6ab0de]">Pinned with Iron (Double Gravity)</span>`
          : `<span class="text-[#e6e4e0]">Tethered to Valley</span>`);

      box.innerHTML = `
        <div class="p-2.5 rounded bg-[#0d1016] border border-[#7a828e]/20">
          <div class="text-[10px] uppercase tracking-widest text-[#7a828e]">Slide Illumination</div>
          <div class="mt-0.5 font-medium">${lightState}</div>
        </div>
        <div class="p-2.5 rounded bg-[#0d1016] border border-[#7a828e]/20">
          <div class="text-[10px] uppercase tracking-widest text-[#7a828e]">Memory Slide Fragment</div>
          <div class="mt-0.5 font-medium">${memoryState}</div>
        </div>
        <div class="p-2.5 rounded bg-[#0d1016] border border-[#7a828e]/20">
          <div class="text-[10px] uppercase tracking-widest text-[#7a828e]">Traveler Identity</div>
          <div class="mt-0.5 font-medium">${nameState}</div>
        </div>
        <div class="p-2.5 rounded bg-[#0d1016] border border-[#7a828e]/20">
          <div class="text-[10px] uppercase tracking-widest text-[#7a828e]">Shadow & Return Path</div>
          <div class="mt-0.5 font-medium">${shadowState}</div>
        </div>
      `;

      if (wishSpan) {
        wishSpan.innerHTML = player.sacrifices.belongings
          ? `Wish: “${esc(player.wishText)}” (Origin memory lost)`
          : `Wish: “${esc(player.wishText)}”`;
      }
    }

    function updateBranchToken(id, status, label) {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = label;
      if (status === "lost") {
        el.className = "px-2 py-0.5 rounded border border-[#b83b2b]/40 bg-[#b83b2b]/10 text-[#7a828e] line-through";
      } else if (status === "scarred") {
        el.className = "px-2 py-0.5 rounded border border-[#6ab0de]/50 bg-[#6ab0de]/15 text-[#6ab0de]";
      } else {
        el.className = "px-2 py-0.5 rounded border border-[#7a828e]/30 bg-[#11141b] text-[#e6e4e0]";
      }
    }

    /********************************************************************
     * PERSISTENT UI, FILMSTRIP & VISUAL SLIDE EFFECTS
     ********************************************************************/
    function applyPersistentSacrificeEffects() {
      document.body.classList.toggle("no-lantern", !!player.sacrifices.lantern);
      document.body.classList.toggle("frost-bitten", !!(player.sacrifices.frostbitten || player.sacrifices.burnedSupplies));
      document.body.classList.toggle("no-belongings", !!player.sacrifices.belongings);
      document.body.classList.toggle("no-name", !!player.sacrifices.name);
      document.body.classList.toggle("no-shadow", !!player.sacrifices.shadow);
      document.body.classList.toggle("heavy-shadow", !!player.sacrifices.ironShadow);

      const hudTraveler = document.getElementById("hud-traveler");
      const btnJournal = document.getElementById("btn-journal");
      const btnInspectSlide = document.getElementById("btn-inspect-slide");
      const remainsBar = document.getElementById("remains-bar");
      const viewportMeta = document.getElementById("viewport-meta");
      const vitalityBadge = document.getElementById("vitality-badge");

      if (player.screen === "title" || player.screen === "setup") {
        hudTraveler.classList.add("hidden");
        btnJournal.classList.add("hidden");
        if (btnInspectSlide) btnInspectSlide.classList.add("hidden");
        remainsBar.classList.add("hidden");
        viewportMeta.classList.add("hidden");
      } else {
        hudTraveler.classList.remove("hidden");
        btnJournal.classList.remove("hidden");
        if (btnInspectSlide) btnInspectSlide.classList.remove("hidden");
        remainsBar.classList.remove("hidden");
        viewportMeta.classList.remove("hidden");

        if (player.sacrifices.name) {
          hudTraveler.textContent = "TRAVELER: THE STRANGER";
        } else if (player.sacrifices.carvedPalm) {
          hudTraveler.textContent = `TRAVELER: ${initialOf(player, true)}. [PALM SCAR]`;
        } else {
          hudTraveler.textContent = `TRAVELER: ${player.name}`;
        }

        if (vitalityBadge) {
          const v = player.vitality ?? 100;
          const vLabel = v >= 90 ? "Warm" : (v >= 65 ? "Shivering" : (v >= 40 ? "Frostbitten" : "Critical"));
          vitalityBadge.textContent = `Vitality: ${v}% (${vLabel})`;
        }
      }

      updateBranchToken(
        "token-lantern",
        player.sacrifices.lantern ? "lost" : (player.sacrifices.frostbitten ? "scarred" : "intact"),
        player.sacrifices.lantern ? "Lantern (Lost)" : (player.sacrifices.frostbitten ? "Half-Light (Frostbite)" : "Lantern")
      );
      updateBranchToken(
        "token-belongings",
        player.sacrifices.belongings ? "lost" : (player.sacrifices.burnedSupplies ? "scarred" : "intact"),
        player.sacrifices.belongings ? "Memories (Lost)" : (player.sacrifices.burnedSupplies ? "1 Memory (No Supplies)" : "Memories")
      );
      updateBranchToken(
        "token-name",
        player.sacrifices.name ? "lost" : (player.sacrifices.carvedPalm ? "scarred" : "intact"),
        player.sacrifices.name ? "Name (Erased)" : (player.sacrifices.carvedPalm ? `Initial '${initialOf(player, true)}.' (Palm)` : "Name")
      );
      updateBranchToken(
        "token-shadow",
        player.sacrifices.shadow ? "lost" : (player.sacrifices.ironShadow ? "scarred" : "intact"),
        player.sacrifices.shadow ? "Shadow (Severed)" : (player.sacrifices.ironShadow ? "Shadow (Iron-Pinned)" : "Shadow")
      );

      const btnTurnBack = document.getElementById("btn-turn-back");
      if (player.sacrifices.shadow || player.screen === "ending" || player.screen === "title" || player.screen === "setup") {
        btnTurnBack.classList.add("hidden");
      } else {
        btnTurnBack.classList.remove("hidden");
      }

      updateFilmstripProgress();
      updateMountainVisuals();
    }

    function updateFilmstripProgress() {
      const badge = document.getElementById("slide-number-badge");
      const label = document.getElementById("slide-scene-label");
      const dots = document.querySelectorAll("#slide-dots-container .slide-dot");

      let activeIdx = 0;
      if (player.screen === "title" || player.screen === "setup") {
        activeIdx = 0;
        badge.textContent = "SLIDE 00 // BASE CAMP";
        label.textContent = "The Valley Timberline";
      } else if (player.screen === "ending" && (player.finalDecision.startsWith("descent") || player.finalDecision === "summit_descent")) {
        activeIdx = player.checkpoint;
        badge.textContent = "SLIDE 06 // THE DESCENT HOME";
        label.textContent = "Returning to the Valley Lights";
      } else if (player.screen === "summit" || player.screen === "ending") {
        activeIdx = 5;
        badge.textContent = "SLIDE 05 // THE MOVING SUMMIT";
        label.textContent = "The Cosmic Altar";
      } else {
        activeIdx = player.checkpoint;
        const cp = CHECKPOINTS[player.checkpoint];
        badge.textContent = cp ? cp.slideBadge : `SLIDE 0${player.checkpoint}`;
        label.textContent = cp ? cp.location : "";
      }

      dots.forEach((dot, idx) => {
        dot.classList.remove("active", "completed");
        if (idx === activeIdx) {
          dot.classList.add("active");
        } else if (idx < activeIdx) {
          dot.classList.add("completed");
        }
      });
    }

    function updateMountainVisuals() {
      const summitGroup = document.getElementById("summit-group");
      const travelerGroup = document.getElementById("traveler-group");
      const checkpointInd = document.getElementById("checkpoint-indicator");
      const summitDist = document.getElementById("summit-distance");
      const valleyDawn = document.getElementById("valley-dawn-bg");
      const svgEl = document.getElementById("mountain-svg");

      if (!summitGroup || !travelerGroup) return;

      const isBaseSlide = player.screen === "title" || player.screen === "setup";
      const isDescentEnding = player.screen === "ending" && (player.finalDecision.startsWith("descent") || player.finalDecision === "summit_descent");
      const showCp1 = player.checkpoint === 1 && !isBaseSlide && !isDescentEnding && player.screen !== "ending";
      const showCp2 = player.checkpoint === 2 && !isDescentEnding && player.screen !== "ending";
      const showCp3 = player.checkpoint === 3 && !isDescentEnding && player.screen !== "ending";
      const showCp4 = player.checkpoint === 4 && !isDescentEnding && player.screen !== "ending";
      const showSummit = player.screen === "summit" || (player.screen === "ending" && !isDescentEnding);

      const propSlide0 = document.getElementById("prop-slide0");
      const propDescent = document.getElementById("prop-descent");
      if (propSlide0) propSlide0.setAttribute("opacity", isBaseSlide ? "1" : "0");
      if (propDescent) propDescent.setAttribute("opacity", isDescentEnding ? "1" : "0");

      document.getElementById("prop-cp1").setAttribute("opacity", showCp1 ? "1" : "0");
      document.getElementById("prop-cp2").setAttribute("opacity", showCp2 ? "1" : "0");
      document.getElementById("prop-cp3").setAttribute("opacity", showCp3 ? "1" : "0");
      document.getElementById("prop-cp4").setAttribute("opacity", showCp4 ? "1" : "0");
      document.getElementById("prop-summit").setAttribute("opacity", showSummit ? "1" : "0");

      valleyDawn.setAttribute("opacity", isDescentEnding ? "1" : "0");

      if (svgEl) {
        if (isBaseSlide) svgEl.style.transform = "scale(1) translate(0px, 0px)";
        else if (isDescentEnding) svgEl.style.transform = "scale(1.04) translate(12px, 4px)";
        else if (showSummit) svgEl.style.transform = "scale(1.08) translate(0px, -6px)";
        else svgEl.style.transform = `scale(${1 + player.checkpoint * 0.015}) translate(${-player.checkpoint * 4}px, 0px)`;
      }

      if (isBaseSlide) {
        summitGroup.style.transform = "scale(1) translateY(10px)";
        travelerGroup.setAttribute("transform", "translate(325, 240)");
        return;
      }

      if (isDescentEnding) {
        summitGroup.style.transform = "scale(0.65) translateY(-18px)";
        travelerGroup.setAttribute("transform", "translate(265, 242) scale(-1, 1)");
        checkpointInd.textContent = "Slide 06 // Valley Descent";
        summitDist.textContent = "Village: Reached";
        return;
      }

      if (showSummit) {
        summitGroup.style.transform = "scale(1.24) translateY(15px)";
        travelerGroup.setAttribute("transform", "translate(425, 234)");
        checkpointInd.textContent = "The Moving Summit";
        summitDist.textContent = "Summit: 0m";
        return;
      }

      const cp = CHECKPOINTS[player.checkpoint];
      if (cp) {
        const yOffset = (player.checkpoint * -10);
        summitGroup.style.transform = `scale(${cp.summitScale}) translateY(${yOffset}px)`;
        const xPos = 355 + player.checkpoint * 18;
        travelerGroup.setAttribute("transform", `translate(${xPos}, 236)`);
        checkpointInd.textContent = cp.location;

        if (player.sacrifices.lantern) {
          summitDist.textContent = "Summit: [Unseen in Dark]";
        } else {
          summitDist.textContent = `Summit: ${cp.apparentDistance}`;
        }
      }
    }

    /********************************************************************
     * SCREEN ROUTER & SLIDE RENDERERS
     ********************************************************************/
    // Picks the particle/colour mood that matches the current slide.
    function syncScene() {
      const s = player.screen;
      const descending = s === "ending" && (String(player.finalDecision).startsWith("descent") || player.finalDecision === "summit_descent");
      let name = "camp";
      if (descending) name = "dawn";
      else if (s === "summit" || s === "ending") name = "summit";
      else if (s === "journey" || s === "consequence") name = { 1: "gate", 2: "ravine", 3: "echoes", 4: "ridge" }[player.checkpoint] || "camp";
      FX.setScene(name);
    }

    function renderCurrentScreen() {
      applyPersistentSacrificeEffects();
      syncScene();
      toggleSlideInspect(false);
      const container = document.getElementById("screen-container");
      if (!container) return;

      if (player.screen === "title") {
        renderTitleScreen(container);
      } else if (player.screen === "setup") {
        renderSetupScreen(container);
      } else if (player.screen === "journey") {
        renderJourneyScreen(container);
      } else if (player.screen === "consequence") {
        renderConsequenceScreen(container);
      } else if (player.screen === "summit") {
        renderSummitScreen(container);
      } else if (player.screen === "ending") {
        renderEndingScreen(container);
      }
    }

    // SCREEN 1 — TITLE SLIDE
    function renderTitleScreen(container) {
      container.innerHTML = `
        <div class="slide-transition max-w-2xl mx-auto text-center py-3">
          <div class="text-xs font-mono uppercase tracking-[0.28em] text-[#d4af37] mb-2">
            Slide 00 // Interactive Visual Story
          </div>
          <h1 class="font-story text-4xl sm:text-6xl text-[#e6e4e0] tracking-wide mb-4">
            The Mountain That Moves
          </h1>
          <p class="font-story text-xl sm:text-2xl italic text-[#7a828e] max-w-xl mx-auto mb-8">
            “At the crown of the peak rests a single wish—yet with every step you climb, the summit recedes and asks what you will leave behind.”
          </p>
          <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button onclick="goToSetupSlide()" class="btn-mountain btn-sacrifice px-8 py-3 text-xs font-mono uppercase tracking-[0.22em]">
              Begin the Ascent →
            </button>
          </div>
        </div>
      `;
    }

    function goToSetupSlide() {
      triggerSlideShutter();
      player.screen = "setup";
      saveState();
      renderCurrentScreen();
    }

    // SCREEN 1B — TRAVELER NAME & WISH SETUP SLIDE
    function renderSetupScreen(container) {
      const wishRadios = WISH_OPTIONS.map((w, idx) => `
        <label class="choice-card flex items-start gap-3 cursor-pointer">
          <input type="radio" name="wish_choice" value="${w.key}" ${idx === 0 ? "checked" : ""} onchange="toggleCustomWishInput(this.value)" class="mt-1 accent-[#d4af37]" />
          <div>
            <div class="font-story text-xl text-[#e6e4e0]">${w.label}</div>
            ${w.wishText ? `<div class="text-xs text-[#7a828e] italic">“${w.wishText}”</div>` : ""}
          </div>
        </label>
      `).join("");

      container.innerHTML = `
        <div class="slide-transition max-w-2xl mx-auto">
          <div class="text-xs font-mono uppercase tracking-[0.24em] text-[#d4af37] mb-1">
            Base Camp Preparation
          </div>
          <h2 class="font-story text-3xl sm:text-4xl text-[#e6e4e0] mb-4">
            Speak Your Name and the Wish You Carry
          </h2>

          <div class="space-y-4 mb-6">
            <div>
              <label class="block text-xs font-mono uppercase tracking-wider text-[#7a828e] mb-1.5">
                Your Name (As known in the valley below)
              </label>
              <input id="input-traveler-name" type="text" maxlength="28" placeholder="e.g., Rowan, Lyra, Kael..." value="${esc(player.originalName || "")}" class="w-full px-4 py-2.5 rounded-lg bg-[#07080a] border border-[#7a828e]/35 text-[#e6e4e0] focus:outline-none focus:border-[#d4af37]" />
            </div>

            <div>
              <label class="block text-xs font-mono uppercase tracking-wider text-[#7a828e] mb-2">
                Why do you climb the Mountain That Moves?
              </label>
              <div class="space-y-2.5">
                ${wishRadios}
              </div>
            </div>

            <div id="custom-wish-wrap" class="hidden pt-1">
              <label class="block text-xs font-mono uppercase tracking-wider text-[#d4af37] mb-1">
                Write your private wish:
              </label>
              <input id="input-custom-wish" type="text" maxlength="95" placeholder="to bring back what was lost to the winter..." class="w-full px-4 py-2.5 rounded-lg bg-[#07080a] border border-[#d4af37]/50 text-[#e6e4e0] focus:outline-none" />
            </div>
          </div>

          <div class="flex items-center justify-between border-t border-[#7a828e]/20 pt-4">
            <button onclick="goBackToTitle()" class="btn-mountain text-xs font-mono uppercase tracking-widest">
              ← Back
            </button>
            <button onclick="confirmSetupAndClimb()" class="btn-mountain btn-sacrifice px-8 text-xs font-mono uppercase tracking-[0.2em]">
              Step onto the Trail →
            </button>
          </div>
        </div>
      `;
    }

    function toggleCustomWishInput(val) {
      const wrap = document.getElementById("custom-wish-wrap");
      if (!wrap) return;
      wrap.classList.toggle("hidden", val !== "custom");
    }

    function confirmSetupAndClimb() {
      const nameInput = document.getElementById("input-traveler-name");
      const rawName = nameInput && nameInput.value.trim() ? nameInput.value.trim() : "Rowan";

      const selectedRadio = document.querySelector('input[name="wish_choice"]:checked');
      const wishKey = selectedRadio ? selectedRadio.value : "power";
      const foundOption = WISH_OPTIONS.find(w => w.key === wishKey) || WISH_OPTIONS[0];

      let finalWishText = foundOption.wishText;
      if (wishKey === "custom") {
        const customInput = document.getElementById("input-custom-wish");
        finalWishText = (customInput && customInput.value.trim())
          ? customInput.value.trim()
          : "to find the truth that waits above the clouds";
      }

      player.originalName = rawName;
      player.name = rawName;
      player.wishKey = wishKey;
      player.wishText = finalWishText;
      player.checkpoint = 1;
      player.screen = "journey";

      triggerSlideShutter();
      playSacrificeTone(196);
      saveState();
      renderCurrentScreen();
    }

    // SCREEN 2 & 3 — CHECKPOINT STORY + 3 BRANCHING CHOICES
    function renderJourneyScreen(container) {
      const cp = CHECKPOINTS[player.checkpoint];
      if (!cp) return;

      const choicesHtml = cp.choices.map(ch => {
        const extraClass = ch.type === "alternate" ? "choice-alt" : (ch.type === "descent" ? "choice-descent" : "");
        const tagColor = ch.type === "alternate" ? "text-[#6ab0de]" : (ch.type === "descent" ? "text-[#e5a952]" : "text-[#d4af37]");
        return `
          <button data-choice="${ch.id}" onclick="commitBranchChoice('${ch.id}')" class="choice-card ${extraClass} w-full block">
            <div class="text-[10px] font-mono uppercase tracking-[0.2em] ${tagColor} mb-1">${ch.tag}</div>
            <div class="font-story text-xl sm:text-2xl text-[#e6e4e0] mb-0.5">${ch.title}</div>
            <div class="text-xs text-[#7a828e] leading-relaxed">${typeof ch.desc === "function" ? ch.desc(player) : ch.desc}</div>
          </button>
        `;
      }).join("");

      container.innerHTML = `
        <div class="slide-transition max-w-2xl mx-auto">
          <div class="flex items-center justify-between text-xs font-mono uppercase tracking-[0.22em] text-[#d4af37] mb-1">
            <span>${cp.slideBadge}</span>
            <span>Apparent Summit: ${player.sacrifices.lantern ? "Unseen" : cp.apparentDistance}</span>
          </div>

          <h2 class="font-story text-3xl sm:text-4xl text-[#e6e4e0] mb-4">${cp.title}</h2>

          <div class="font-story text-xl sm:text-2xl leading-relaxed text-[#e6e4e0]/90 mb-5">
            ${cp.story(player)}
          </div>

          <!-- Roadside Stone Inscription (Blurred if Lantern was sacrificed) -->
          <div class="p-3.5 rounded-lg bg-[#07080a]/90 border border-[#7a828e]/25 mb-6">
            <div class="text-[10px] font-mono uppercase tracking-widest text-[#7a828e] mb-1">
              Roadside Stone Tablet ${player.sacrifices.lantern ? "(Unreadable in the Dark)" : ""}
            </div>
            <div class="inscription-text font-story italic text-lg text-[#d4af37]/90">
              ${cp.inscription}
            </div>
          </div>

          <div class="space-y-3 border-t border-[#7a828e]/20 pt-5">
            <div class="text-xs font-mono uppercase tracking-[0.2em] text-[#7a828e] mb-1">
              Choose How You Answer the Mountain
            </div>
            ${choicesHtml}
          </div>
        </div>
      `;
    }

    function commitBranchChoice(choiceId) {
      if (busy) return;           // ignore double-clicks
      busy = true;
      const cp = CHECKPOINTS[player.checkpoint];
      const lockedBox = document.querySelector("#screen-container .space-y-3");
      if (lockedBox) lockedBox.classList.add("choices-locked");
      const chosenCard = document.querySelector(`[data-choice="${choiceId}"]`);
      if (chosenCard) chosenCard.classList.add("is-chosen");
      const chObj = cp && cp.choices ? cp.choices.find(c => c.id === choiceId) : null;
      if (chObj && chObj.toast) {
        showSlideActionToast(chObj.toast);
      }

      const burstColor = choiceId.startsWith("descent")
        ? "#e5a952"
        : (chObj && chObj.type === "alternate" ? "#6ab0de" : "#d4af37");
      FX.burst(burstColor, 36);
      FX.react(choiceId.startsWith("descent") ? "descent" : (chObj && chObj.type === "alternate" ? "bargain" : "sacrifice"));

      // Handle Turning Back / Descent Choices immediately
      if (choiceId.startsWith("descent_")) {
        setTimeout(() => {
          player.finalDecision = choiceId;
          player.screen = "ending";
          triggerSlideShutter();
          playSacrificeTone(146);
          busy = false;
          saveState();
          renderCurrentScreen();
        }, 520);
        return;
      }

      setTimeout(() => {
        // Checkpoint 1 Branches (Obsidian Gate)
        if (choiceId === "lantern") player.sacrifices.lantern = true;
        if (choiceId === "briars") {
          player.sacrifices.frostbitten = true;
          player.vitality = Math.max(10, (player.vitality || 100) - 25);
        }

        // Checkpoint 2 Branches (Weeping Ravine)
        if (choiceId === "belongings") player.sacrifices.belongings = true;
        if (choiceId === "burn_supplies") {
          player.sacrifices.burnedSupplies = true;
          player.vitality = Math.max(10, (player.vitality || 100) - 25);
        }

        // Checkpoint 3 Branches (Hall of Echoes)
        if (choiceId === "name") {
          player.sacrifices.name = true;
          player.name = "The Stranger";
        }
        if (choiceId === "carve_palm") {
          player.sacrifices.carvedPalm = true;
          player.vitality = Math.max(10, (player.vitality || 100) - 25);
        }

        // Checkpoint 4 Branches (Sunless Ridge)
        if (choiceId === "shadow") player.sacrifices.shadow = true;
        if (choiceId === "iron_shadow") {
          player.sacrifices.ironShadow = true;
          player.vitality = Math.max(10, (player.vitality || 100) - 20);
        }

        player.lastChoiceType = choiceId;
        triggerSlideShutter();
        playSacrificeTone(176 - player.checkpoint * 14);
        player.screen = "consequence";
        busy = false;
        saveState();
        renderCurrentScreen();
      }, 520);
    }

    // CONSEQUENCE SLIDE AFTER CHECKPOINT DECISION
    function renderConsequenceScreen(container) {
      const cp = CHECKPOINTS[player.checkpoint];

      container.innerHTML = `
        <div class="slide-transition max-w-2xl mx-auto">
          <div class="text-xs font-mono uppercase tracking-[0.25em] text-[#d4af37]/80 mb-2">Consequence Slide — Stage ${player.checkpoint}</div>
          <h3 class="font-story text-2xl sm:text-3xl text-[#e6e4e0] mb-4">The Mountain Remembers Your Choice</h3>

          <div class="font-story text-xl sm:text-2xl leading-relaxed text-[#e6e4e0]/90 mb-8">
            ${cp.consequenceText(player)}
          </div>

          <div class="flex items-center justify-between border-t border-[#7a828e]/15 pt-4">
            <span class="text-xs text-[#7a828e] italic font-story">The projector advances to the next ridge...</span>
            <button onclick="advanceAfterConsequence()" class="btn-mountain btn-sacrifice px-8 text-xs font-mono uppercase tracking-[0.2em]">
              Advance to Next Slide →
            </button>
          </div>
        </div>
      `;
    }

    function advanceAfterConsequence() {
      triggerSlideShutter();
      if (player.checkpoint < 4) {
        player.checkpoint += 1;
        player.screen = "journey";
      } else {
        player.checkpoint = 5;
        player.screen = "summit";
      }
      saveState();
      renderCurrentScreen();
    }

    // SCREEN 4 — THE SUMMIT SLIDE & DYNAMIC FINAL CHOICES
    function renderSummitScreen(container) {
      const wishMemoryNote = player.sacrifices.belongings
        ? `You know you came here wishing <em>“${esc(player.wishText)}”</em>—yet because your keepsakes were given to the Weeping Ravine, you can no longer recall whose face or what warmth made that wish worth a life.`
        : `Because you guarded your memory across the Weeping Ravine, you still clearly remember every face at home and why your wish—<em>“${esc(player.wishText)}”</em>—matters.`;

      const identityNote = player.sacrifices.name
        ? `You stand before the altar as <strong>The Stranger</strong>, your birth name left behind in the Hall of Echoes.`
        : (player.sacrifices.carvedPalm
          ? `Your frostbitten palm throbs where the initial <strong>${initialOf(player)}.</strong> is carved into your skin.`
          : `Your voice trembles in the thin air before the cosmic cleft.`);

      let extraSummitChoices = `
        <button onclick="selectFinalEnding('guardian')" class="choice-card choice-alt w-full block">
          <div class="text-[10px] font-mono uppercase tracking-[0.22em] text-[#6ab0de] mb-1">Become the Summit Beacon</div>
          <div class="font-story text-xl text-[#e6e4e0]">Give Up Your Wish to Light the Trail for Future Climbers</div>
          <div class="text-xs text-[#7a828e]">Instead of claiming your wish for yourself, become the keeper of the summit shrine so others do not lose their way in the dark.</div>
        </button>
      `;

      if (!player.sacrifices.shadow) {
        extraSummitChoices += `
          <button onclick="selectFinalEnding('summit_descent')" class="choice-card choice-descent w-full block">
            <div class="text-[10px] font-mono uppercase tracking-[0.22em] text-[#d4af37] mb-1">Unlocked Because You Pinned Your Shadow with Iron</div>
            <div class="font-story text-xl text-[#e6e4e0]">Turn Your Back on the Wish & Follow Your Tattered Shadow Home</div>
            <div class="text-xs text-[#7a828e]">You dragged double the weight of your shadow up the Sunless Ridge. Because it still points down the mountain, you alone can walk back into the valley alive.</div>
          </button>
        `;
      }

      container.innerHTML = `
        <div class="slide-transition max-w-2xl mx-auto">
          <div class="flex items-center justify-between text-xs font-mono uppercase tracking-[0.25em] text-[#d4af37] mb-2">
            <span>SLIDE 05 // THE MOVING SUMMIT</span>
            <span>The Peak No Longer Recedes</span>
          </div>

          <h2 class="font-story text-3xl sm:text-5xl text-[#e6e4e0] mb-4">The Cosmic Altar of What Remains</h2>

          <div class="font-story text-xl sm:text-2xl leading-relaxed text-[#e6e4e0]/90 space-y-3.5 mb-6">
            <p>
              For the first time since Base Camp, the mountain stops growing. Above the altar, the sky opens into a vault of still gold.
            </p>
            <p>${wishMemoryNote}</p>
            <p>${identityNote}</p>
            <p>
              Before the cleft of light, the final price is asked.
            </p>
          </div>

          <div class="space-y-3 border-t border-[#7a828e]/20 pt-5">
            <div class="text-xs font-mono uppercase tracking-[0.2em] text-[#7a828e] mb-2">Choose Your Ending</div>

            <button onclick="selectFinalEnding('memories')" class="choice-card w-full block">
              <div class="text-[10px] font-mono uppercase tracking-[0.22em] text-[#d4af37] mb-1">The Price of Remembrance</div>
              <div class="font-story text-xl text-[#e6e4e0]">Surrender Your Remaining Memories for the Wish</div>
              <div class="text-xs text-[#7a828e]">Your wish is granted in full, though you will never remember why you wanted it or who you were before.</div>
            </button>

            <button onclick="selectFinalEnding('humanity')" class="choice-card w-full block">
              <div class="text-[10px] font-mono uppercase tracking-[0.22em] text-[#d4af37] mb-1">The Price of Feeling</div>
              <div class="font-story text-xl text-[#e6e4e0]">Surrender Your Humanity & Longing</div>
              <div class="text-xs text-[#7a828e]">Receive exactly what you asked for, untouched by grief, warmth, joy, or regret.</div>
            </button>

            ${extraSummitChoices}

            <button onclick="selectFinalEnding('refuse')" class="choice-card choice-descent w-full block">
              <div class="text-[10px] font-mono uppercase tracking-[0.22em] text-[#7a828e] mb-1">Withhold the Final Price</div>
              <div class="font-story text-xl text-[#e6e4e0]/85">Refuse the Last Altar & Sit in the Silent Clouds</div>
              <div class="text-xs text-[#7a828e]">Leave your wish ungranted rather than surrender the last fragment of your soul.</div>
            </button>
          </div>
        </div>
      `;
    }

    function selectFinalEnding(decisionKey) {
      player.finalDecision = decisionKey;
      player.screen = "ending";
      triggerSlideShutter();
      FX.burst("#d4af37", 55);
      FX.react("sacrifice");
      playSacrificeTone(135);
      saveState();
      renderCurrentScreen();
    }

    // SCREEN 4 PART B — ALL TAILORED DESCENT & SUMMIT ENDINGS
    function renderEndingScreen(container) {
      let endingTitle = "";
      let endingSubtitle = "";
      let endingParagraphs = [];

      if (player.finalDecision === "descent_1") {
        endingTitle = "Ending I — The Intact Return (Turned Back at the Obsidian Gate)";
        endingSubtitle = "You chose the warmth of the valley village over the cold promise of the peak.";
        endingParagraphs = [
          `At the Obsidian Gate, <strong>${esc(player.originalName)}</strong> looked up at the thorn-choked darkness—and decided the mountain's first toll was already too high.`,
          `You walk back down through the timberline toward the warm amber windows of the village below. Your camp lantern still glows in your hand, your silver watch and letter rest safely in your coat, and your name is still your own.`,
          `Your wish—to <em>“${esc(player.wishText)}”</em>—remains ungranted by the summit, yet you return home whole enough to build a life with your own two hands.`
        ];
      } else if (player.finalDecision === "descent_2") {
        endingTitle = "Ending II — The Half-Shadowed Homecoming (Turned Back at the Weeping Ravine)";
        endingSubtitle = "You refused to surrender the memory of those you love to the abyss.";
        endingParagraphs = [
          `Standing before the frayed rope bridge of the Weeping Ravine, <strong>${esc(player.originalName)}</strong> touched the folded letter in their coat and refused to let the chasm drink their past.`,
          `${player.sacrifices.lantern
            ? "Because you surrendered your lantern at the Obsidian Gate, you had to feel your way back down the cliffside in total darkness until the village lights rose to meet you."
            : "With your frostbite-scarred hands still shielding your cracked lantern, you limped back down the stone steps toward the timberline."}`,
          `You return to the valley changed by the mountain's cold, but when you open your door, you still remember the faces of everyone waiting inside.`
        ];
      } else if (player.finalDecision === "descent_3") {
        endingTitle = "Ending III — The Half-Forgotten Wanderer (Turned Back at the Hall of Echoes)";
        endingSubtitle = "You walked away from the monolith mirrors to save your name.";
        endingParagraphs = [
          `At the Hall of Echoes, the mirrors reached for the name <strong>${esc(player.originalName)}</strong>—and for the first time, you refused to climb another step.`,
          `${player.sacrifices.belongings
            ? "Because you left your keepsakes in the Weeping Ravine, you walk back into the valley village as someone who still knows their own name, yet cannot quite remember which house or hearth once belonged to them."
            : "Exhausted and shivering in your supply-less coat, you clutch the saved letter to your chest and descend the ridges with both your name and your memories intact."}`,
          `The summit never answered your wish, yet you saved the person who made it.`
        ];
      } else if (player.finalDecision === "descent_4") {
        endingTitle = "Ending IV — The Nameless Return (Turned Back at the Sunless Ridge)";
        endingSubtitle = "Beneath the blood-gold eclipse, you chose your shadow over the summit.";
        endingParagraphs = [
          `One ridge below the summit, beneath the blood-gold eclipse, you looked down at your shadow straining toward the valley—and refused to sever it.`,
          `${player.sacrifices.name
            ? "When you finally reach the village at dawn, no one recognizes 'The Stranger' who walks down from the timberline, nor can you speak the name you once wore—yet your shadow walks faithfully beside you in the morning sun."
            : "With your initial carved into your palm and frostbite on your brow, you follow your shadow step by step back into the warmth of the valley."}`,
          `You stood higher than almost any mortal climber, and proved stronger than the mountain by choosing to come home.`
        ];
      } else if (player.finalDecision === "summit_descent") {
        endingTitle = "True Descent Ending — The One Who Walked Down from the Crown";
        endingSubtitle = "Because you pinned your shadow with iron, you returned alive from the summit itself.";
        endingParagraphs = [
          `At the Cosmic Altar of the Moving Summit, ${getDisplayName(player, true)} looked into the cleft of light and saw that the final price would hollow out the last truth of their soul.`,
          `Because you pinned your tattered shadow to your heels with iron pitons on the Sunless Ridge—bearing double gravity with every agonizing step—the trail back down the mountain remained open to you alone.`,
          `Turning your back on the altar, you follow your iron-pinned shadow all the way down into the warm valley dawn: the only traveler in legend to touch the summit and return to the living world.`
        ];
      } else if (player.finalDecision === "guardian") {
        endingTitle = "Ending V — The Beacon of the Moving Peak";
        endingSubtitle = "You gave up your personal wish to light the mountain for those who climb after you.";
        endingParagraphs = [
          `Standing before the cleft of light, ${getDisplayName(player, true)} chose not to spend the summit's power on <em>“${esc(player.wishText)}”</em>.`,
          `Instead, you poured what remained of your warmth into the cosmic altar, igniting a golden beacon visible across every ridge from the Sunless Spine down to the Obsidian Gate.`,
          `Future climbers who ascend the mountain in the dark will read the roadside warnings by your light—and know when to turn back before they lose themselves.`
        ];
      } else if (player.finalDecision === "refuse") {
        endingTitle = "Ending VI — The Unfinished Journey";
        endingSubtitle = "You reached the summit, looked upon the final price, and withheld your hand.";
        endingParagraphs = [
          `At the crown of still stone, ${getDisplayName(player, true)} refused to surrender the final fragment of their spirit.`,
          `The cleft of golden light slowly closes. Your wish—to <em>“${esc(player.wishText)}”</em>—is neither granted nor corrupted into an empty echo.`,
          `${player.sacrifices.shadow
            ? "With your shadow severed on the ridge below, you cannot descend—so you sit quietly above the sea of clouds, whole in the small, silent truth of what you refused to trade."
            : "You sit in the quiet clouds above the world, knowing your mind and heart still belong to you alone."}`
        ];
      } else if (player.finalDecision === "memories") {
        endingTitle = "Ending VII — The Empty Victory";
        endingSubtitle = "The mountain granted your wish in full, and took the reason you ever wanted it.";
        endingParagraphs = [
          `Light pours from the altar as your wish—to <em>“${esc(player.wishText)}”</em>—reshapes reality around you.`,
          `Yet as the golden warmth settles into your hands, your last memories dissolve like snow in dark water. You hold the miracle you climbed for, staring at it in serene confusion, unable to recall who you were or why this gift once meant everything.`
        ];
      } else {
        endingTitle = "Ending VIII — The Stranger at the Summit";
        endingSubtitle = "You received everything you asked for, and became someone who no longer needs it.";
        endingParagraphs = [
          `The mountain fulfills its ancient promise: what you wished for—<em>“${esc(player.wishText)}”</em>—is yours beyond question.`,
          `But with your humanity and longing left upon the stone altar, your pulse is as still and cold as the glacier. The figure standing on the peak possesses the wish of <strong>${esc(player.originalName)}</strong>, yet feels neither triumph nor sorrow.`
        ];
      }

      const lossList = [];
      if (player.sacrifices.lantern) lossList.push("Lantern Surrendered (Darkness)");
      if (player.sacrifices.frostbitten) lossList.push("Half-Light Kept (Frostbite Scars)");
      if (player.sacrifices.belongings) lossList.push("Keepsakes Surrendered (Memories Erased)");
      if (player.sacrifices.burnedSupplies) lossList.push("1 Memory Saved (Supplies Burned)");
      if (player.sacrifices.name) lossList.push(`Name '${esc(player.originalName)}' Erased`);
      if (player.sacrifices.carvedPalm) lossList.push(`Initial '${initialOf(player)}.' Carved in Palm`);
      if (player.sacrifices.shadow) lossList.push("Shadow Severed (No Return)");
      if (player.sacrifices.ironShadow) lossList.push("Shadow Pinned with Iron");

      container.innerHTML = `
        <div class="slide-transition max-w-2xl mx-auto">
          <div class="text-xs font-mono uppercase tracking-[0.25em] text-[#d4af37] mb-1">${endingTitle}</div>
          <h2 class="font-story text-2xl sm:text-4xl text-[#e6e4e0] italic mb-5">${endingSubtitle}</h2>

          <div class="font-story text-xl sm:text-2xl leading-relaxed text-[#e6e4e0]/90 space-y-4 mb-6">
            ${endingParagraphs.map(p => `<p>${p}</p>`).join("")}
          </div>

          <div class="p-4 rounded bg-[#07080a]/90 border border-[#7a828e]/25 mb-6 text-xs text-[#7a828e] space-y-1.5">
            <div class="uppercase tracking-widest text-[#e6e4e0]/80 font-medium">Chronicle of Your Climb</div>
            <div><strong class="text-[#e6e4e0]">Birth Name:</strong> ${esc(player.originalName)} → <strong class="text-[#d4af37]">${getDisplayName(player, false)}</strong></div>
            <div><strong class="text-[#e6e4e0]">Original Wish:</strong> “${esc(player.wishText)}”</div>
            <div><strong class="text-[#e6e4e0]">Choices & Scars:</strong> ${lossList.length ? lossList.join(" · ") : "None (Turned back whole at Base/Stage I)"}</div>
          </div>

          <div class="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
            <button onclick="startNewClimb()" class="btn-mountain btn-sacrifice w-full sm:w-auto px-8 text-xs font-mono uppercase tracking-[0.2em]">
              Begin Another Climb ↻
            </button>
          </div>
        </div>
      `;
    }

    /********************************************************************
     * MODALS: JOURNAL ("WHAT REMAINS"), TURN BACK, RESTART & GITHUB EXPORT
     ********************************************************************/
    function toggleJournalModal(show) {
      const modal = document.getElementById("journal-modal");
      const body = document.getElementById("journal-body");
      if (!modal || !body) return;

      if (!show) {
        modal.classList.add("hidden");
        modal.classList.remove("flex");
        return;
      }

      const nameEntry = player.sacrifices.name
        ? `<p><span class="text-[#7a828e] uppercase text-xs tracking-widest block">Identity</span>The name you carried from the valley has been left inside the Hall of Echoes. Even your own thoughts call you <em>The Stranger</em>.</p>`
        : (player.sacrifices.carvedPalm
          ? `<p><span class="text-[#6ab0de] uppercase text-xs tracking-widest block">Identity (Scarred)</span>The full sound of your name was fractured in the Hall of Echoes, but the initial <strong>${initialOf(player)}.</strong> is carved into your palm.</p>`
          : `<p><span class="text-[#7a828e] uppercase text-xs tracking-widest block">Identity</span>You are <strong>${esc(player.name)}</strong>.</p>`);

      const memoryEntry = player.sacrifices.belongings
        ? `<p><span class="text-[#7a828e] uppercase text-xs tracking-widest block">Keepsakes & Memory</span>Your pockets are empty. Whatever watch or letter you once carried was given to the Weeping Ravine, along with the faces of home.</p>`
        : (player.sacrifices.burnedSupplies
          ? `<p><span class="text-[#6ab0de] uppercase text-xs tracking-widest block">One Saved Memory (Supplies Burned)</span>You burned your rations and pack at the Weeping Ravine, but fiercely guarded your folded letter from home.</p>`
          : `<p><span class="text-[#7a828e] uppercase text-xs tracking-widest block">Keepsakes & Memory</span>${player.keptMemoryText}</p>`);

      const wishEntry = `<p><span class="text-[#7a828e] uppercase text-xs tracking-widest block">The Wish</span>You climb the mountain wishing <em>“${esc(player.wishText)}”</em>.</p>`;

      body.innerHTML = `${nameEntry}<hr class="border-[#7a828e]/15">${memoryEntry}<hr class="border-[#7a828e]/15">${wishEntry}`;
      modal.classList.remove("hidden");
      modal.classList.add("flex");
    }

    function showCustomDialog(title, message, actionsHtml) {
      const modal = document.getElementById("dialog-modal");
      document.getElementById("dialog-title").textContent = title;
      document.getElementById("dialog-message").innerHTML = message;
      document.getElementById("dialog-actions").innerHTML = actionsHtml;
      modal.classList.remove("hidden");
      modal.classList.add("flex");
    }

    function closeCustomDialog() {
      const modal = document.getElementById("dialog-modal");
      modal.classList.add("hidden");
      modal.classList.remove("flex");
    }

    function attemptTurnBackModal() {
      if (player.sacrifices.shadow) return;
      const cpNum = Math.min(4, Math.max(1, player.checkpoint || 1));
      showCustomDialog(
        "Turn Back Down the Mountain?",
        `Your shadow still points back down toward the valley lights below. If you give up the climb here at Stage ${cpNum}, you will descend with what remains of yourself and trigger a unique Turning Back ending.`,
        `
          <button onclick="closeCustomDialog()" class="btn-mountain text-xs font-mono uppercase tracking-widest">Keep Climbing</button>
          <button onclick="closeCustomDialog(); commitBranchChoice('descent_${cpNum}');" class="btn-mountain btn-sacrifice text-xs font-mono uppercase tracking-widest">Turn Back & Descend</button>
        `
      );
    }

    function promptRestart() {
      showCustomDialog(
        "Reset Your Climb?",
        "This will clear your current journey and return you to Slide 00 (Base Camp).",
        `
          <button onclick="closeCustomDialog()" class="btn-mountain text-xs font-mono uppercase tracking-widest">Cancel</button>
          <button onclick="closeCustomDialog(); startNewClimb();" class="btn-mountain btn-sacrifice text-xs font-mono uppercase tracking-widest">Reset Run</button>
        `
      );
    }

    /********************************************************************
     * ABOUT MODAL
     ********************************************************************/
    function toggleAboutModal(show) {
      const modal = document.getElementById("about-modal");
      if (!modal) return;
      modal.classList.toggle("hidden", !show);
      modal.classList.toggle("flex", !!show);
    }

    // Start the game once the page is ready.
    document.addEventListener("DOMContentLoaded", () => {
      loadState();
      const container = document.getElementById("screen-container");
      if (container) container.setAttribute("aria-live", "polite");
      ["journal-modal", "dialog-modal"].forEach((id) => {
        const m = document.getElementById(id);
        if (m) { m.setAttribute("role", "dialog"); m.setAttribute("aria-modal", "true"); }
      });
      // Escape closes whatever is open
      document.addEventListener("keydown", (e) => {
        if (e.key !== "Escape") return;
        toggleJournalModal(false); closeCustomDialog(); toggleAboutModal(false); toggleSlideInspect(false);
      });
      renderCurrentScreen();
    });
