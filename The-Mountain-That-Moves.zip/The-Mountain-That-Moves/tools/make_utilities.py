#!/usr/bin/env python3
"""Generates css/utilities.css: a small static subset of the Tailwind-style
utility classes used in index.html and js/game.js, so the game needs no CDN.
Only needed if you add NEW utility classes. Run from the project root:
    python3 tools/make_utilities.py"""
import re, glob

SP = lambda n: f"{float(n)*0.25:g}rem"
TXT = {"base":("1rem","1.5rem"),"xs":(".75rem","1rem"),"sm":(".875rem","1.25rem"),"lg":("1.125rem","1.75rem"),"xl":("1.25rem","1.75rem"),
       "2xl":("1.5rem","2rem"),"3xl":("1.875rem","2.25rem"),"4xl":("2.25rem","2.5rem"),"5xl":("3rem","1"),"6xl":("3.75rem","1")}
TRACK = {"wide":".025em","wider":".05em","widest":".1em"}
MAXW = {"md":"28rem","lg":"32rem","xl":"36rem","2xl":"42rem","4xl":"56rem"}
ROUND = {"rounded":".25rem","rounded-lg":".5rem","rounded-xl":".75rem","rounded-full":"9999px"}
DISPLAY = {"block":"block","inline":"inline","flex":"flex","grid":"grid","hidden":"none"}
EXACT = {
 "absolute":"position:absolute","relative":"position:relative","fixed":"position:fixed",
 "italic":"font-style:italic","uppercase":"text-transform:uppercase","line-through":"text-decoration-line:line-through",
 "cursor-pointer":"cursor:pointer","pointer-events-none":"pointer-events:none","overflow-hidden":"overflow:hidden",
 "object-cover":"object-fit:cover","mx-auto":"margin-left:auto;margin-right:auto","my-auto":"margin-top:auto;margin-bottom:auto",
 "flex-1":"flex:1 1 0%","flex-col":"flex-direction:column","flex-wrap":"flex-wrap:wrap","flex-row":"flex-direction:row",
 "items-center":"align-items:center","items-start":"align-items:flex-start",
 "justify-between":"justify-content:space-between","justify-center":"justify-content:center","justify-end":"justify-content:flex-end",
 "font-medium":"font-weight:500","leading-relaxed":"line-height:1.625","text-center":"text-align:center",
 "border":"border-width:1px","border-b":"border-bottom-width:1px","border-t":"border-top-width:1px",
 "inset-0":"inset:0","inset-x-0":"left:0;right:0","w-full":"width:100%","h-full":"height:100%","min-h-screen":"min-height:100vh",
 "w-auto":"width:auto",
 "shadow-2xl":"box-shadow:0 25px 50px -12px rgba(0,0,0,.45)","shadow-lg":"box-shadow:0 10px 15px -3px rgba(0,0,0,.4),0 4px 6px -4px rgba(0,0,0,.4)",
 "backdrop-blur-sm":"backdrop-filter:blur(4px)","backdrop-blur-md":"backdrop-filter:blur(12px)",
 "bg-gradient-to-b":"background-image:linear-gradient(to bottom,var(--from),var(--via),var(--to))",
 "transition":"transition-property:color,background-color,border-color,opacity,box-shadow,transform,filter;transition-duration:.15s;transition-timing-function:cubic-bezier(.4,0,.2,1)",
 "transition-all":"transition-property:all;transition-duration:.15s;transition-timing-function:cubic-bezier(.4,0,.2,1)",
 "transition-opacity":"transition-property:opacity;transition-duration:.15s;transition-timing-function:cubic-bezier(.4,0,.2,1)",
 "transition-transform":"transition-property:transform;transition-duration:.15s;transition-timing-function:cubic-bezier(.4,0,.2,1)",
 "outline-none":"outline:2px solid transparent;outline-offset:2px",
}
def rgba(h, a=None):
    h = h.lstrip("#"); r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    return f"rgba({r},{g},{b},{int(a)/100:g})" if a is not None else f"#{h}"

def decl(c):
    if c in EXACT: return EXACT[c]
    if c in DISPLAY: return f"display:{DISPLAY[c]}"
    if c in ROUND: return f"border-radius:{ROUND[c]}"
    m = re.fullmatch(r"(p|px|py|pt|pb|mb|mt)-([\d.]+)", c)
    if m:
        k, v = m.groups(); v = SP(v)
        return {"p":f"padding:{v}","px":f"padding-left:{v};padding-right:{v}","py":f"padding-top:{v};padding-bottom:{v}",
                "pt":f"padding-top:{v}","pb":f"padding-bottom:{v}","mb":f"margin-bottom:{v}","mt":f"margin-top:{v}"}[k]
    m = re.fullmatch(r"(w|h)-([\d.]+)", c)
    if m: return f"{'width' if m[1]=='w' else 'height'}:{SP(m[2])}"
    m = re.fullmatch(r"gap-([\d.]+)", c)
    if m: return f"gap:{SP(m[1])}"
    m = re.fullmatch(r"(top|bottom|left|right)-([\d.]+)", c)
    if m: return f"{m[1]}:{SP(m[2])}"
    m = re.fullmatch(r"z-(\d+)", c)
    if m: return f"z-index:{m[1]}"
    m = re.fullmatch(r"opacity-(\d+)", c)
    if m: return f"opacity:{int(m[1])/100:g}"
    m = re.fullmatch(r"duration-(\d+)", c)
    if m: return f"transition-duration:{m[1]}ms"
    m = re.fullmatch(r"grid-cols-(\d+)", c)
    if m: return f"grid-template-columns:repeat({m[1]},minmax(0,1fr))"
    m = re.fullmatch(r"text-(base|xs|sm|lg|xl|[2-6]xl)", c)
    if m: s, l = TXT[m[1]]; return f"font-size:{s};line-height:{l}"
    m = re.fullmatch(r"tracking-(wide|wider|widest)", c)
    if m: return f"letter-spacing:{TRACK[m[1]]}"
    m = re.fullmatch(r"max-w-(md|lg|xl|2xl|4xl)", c)
    if m: return f"max-width:{MAXW[m[1]]}"
    m = re.fullmatch(r"(min-h|max-h)-\[(.+)\]", c)
    if m: return f"{'min-height' if m[1]=='min-h' else 'max-height'}:{m[2]}"
    m = re.fullmatch(r"tracking-\[(.+)\]", c)
    if m: return f"letter-spacing:{m[1]}"
    m = re.fullmatch(r"text-\[(\d+px)\]", c)
    if m: return f"font-size:{m[1]}"
    m = re.fullmatch(r"shadow-\[(.+)\]", c)
    if m: return "box-shadow:" + m[1].replace("_", " ")
    m = re.fullmatch(r"(bg|text|border|accent|from|via|to)-\[(#[0-9a-fA-F]{6})\](?:/(\d+))?", c)
    if m:
        k, h, a = m.groups(); col = rgba(h, a)
        return {"bg":f"background-color:{col}","text":f"color:{col}","border":f"border-color:{col}",
                "accent":f"accent-color:{col}","from":f"--from:{col}","via":f"--via:{col}","to":f"--to:{col}"}[k]
    m = re.fullmatch(r"bg-black/(\d+)", c)
    if m: return f"background-color:rgba(0,0,0,{int(m[1])/100:g})"
    return None

def esc(c): return re.sub(r"([^a-zA-Z0-9_-])", r"\\\1", c)

def collect():
    toks = set()
    for f in glob.glob("index.html") + glob.glob("js/*.js"):
        s = open(f, encoding="utf8").read()
        for m in re.finditer(r'class(?:Name)?\s*=\s*"([^"]*)"', s): toks.update(m[1].split())
        for m in re.finditer(r'classList\.(?:add|remove|toggle)\(([^)]*)\)', s): toks.update(re.findall(r'"([^"]+)"', m[1]))
    return {t for t in toks if t and "$" not in t and "{" not in t}

def build():
    toks = collect(); base = []; sm = []; hov = []; sel = []; sp = []; bad = []
    for t in sorted(toks):
        v, name = (t.split(":", 1) if t.startswith(("sm:", "hover:", "focus:", "selection:")) else ("", t))
        if name.startswith("space-y-"):
            sp.append(f".{esc(t)}>:not([hidden])~:not([hidden]){{margin-top:{SP(name[8:])}}}"); continue
        d = decl(name)
        if d is None: bad.append(t); continue
        rule = f".{esc(t)}"
        if v == "hover": hov.append(f"{rule}:hover{{{d}}}")
        elif v == "focus": hov.append(f"{rule}:focus{{{d}}}")
        elif v == "selection": sel.append(f"{rule} ::selection,{rule}::selection{{{d}}}")
        elif v == "sm": sm.append(f"{rule}{{{d}}}")
        else: base.append((t, f"{rule}{{{d}}}"))
    order = {"block":0, "inline":1, "flex":2, "grid":3, "hidden":4}   # Tailwind order: hidden wins
    plain = [r for t, r in base if t not in order]
    disp = [r for _, r in sorted((order[t], r) for t, r in base if t in order)]
    css = "/* GENERATED by tools/make_utilities.py - static utility subset (no CDN needed). */\n"
    css += "*,::before,::after{box-sizing:border-box;border:0 solid rgba(122,130,142,.3)}\n"
    css += "html{line-height:1.5;-webkit-text-size-adjust:100%}body{margin:0}h1,h2,h3,p,hr{margin:0}h1,h2,h3{font-size:inherit;font-weight:inherit}\n"
    css += "button,input,textarea{font:inherit;color:inherit;margin:0}button{background:transparent;cursor:pointer}svg,canvas,img{display:block}hr{border-top-width:1px;height:0}\n"
    css += "\n".join(plain) + "\n" + "\n".join(disp) + "\n" + "\n".join(sp) + "\n"
    css += "\n".join(hov) + "\n" + "\n".join(sel) + "\n@media (min-width:640px){\n" + "\n".join(sm) + "\n}\n"
    open("css/utilities.css", "w", encoding="utf8").write(css)
    print(f"{len(toks)} class tokens scanned; {len(bad)} are custom (non-utility):", " ".join(bad))

build()
